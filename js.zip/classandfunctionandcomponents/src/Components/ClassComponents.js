import React from 'react'
class ClassComponents extends React.Component{
    render(){
        return <h2>Custom Class Component</h2>
    };
}
 export default ClassComponents;