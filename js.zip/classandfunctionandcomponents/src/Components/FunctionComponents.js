function FunctionalComponents(){
    return(
        <h2> Custom Function Component</h2>
    );
}
export default FunctionalComponents;