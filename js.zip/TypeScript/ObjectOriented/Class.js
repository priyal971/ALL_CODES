var Person = /** @class */ (function () {
    function Person(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    Person.prototype.showPersonDetails = function () {
        console.log("person Details:" + this.firstName + " " + this.lastName);
    };
    return Person;
}());
var obj = new Person("Janki", "Purohit");
obj.showPersonDetails();
