class Person{
    private _age: number;

    
    public set age(theAge: number){
        if(theAge <= 0 || theAge >= 100){
            throw new Error('the age is invalid');
        }
        this._age = theAge;
    }
    public getAge(): number{
        return this._age;
    }
}
var personObj=new Person();
personObj.age=50;
console.log (personObj.getAge());