class ParentClass{
    display():void{
        console.log("Display method from Parent class")
    }
}
class ChildClass extends ParentClass{
    display(): void {
        super.display()
        console.log("display method from child class")
    }
    hello():void{
        console.log("Hello from Child Class")
    }
}
var parentObj = new ParentClass();
parentObj.display();
var childObj = new ChildClass();
childObj.display();
childObj.hello();
class ParentClass2{
    display():void{
        console.log("Display method from parent class")
    }
}
class ChildClass2 extends ParentClass2{
    display(): void {
        console.log("display method from child class..!")
    }
    hello():void{
        console.log("Hello from Child class!")
    }
}
var parentObj = new ParentClass();
parentObj.display();
var childObj = new ChildClass();
childObj.display();
childObj.hello();