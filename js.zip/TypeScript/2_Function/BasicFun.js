function addNum(a, b) {
    return a + b;
}
function showMes(mes) {
    console.log(mes.toUpperCase());
}
var addNum2;
var addNum3 = function (x, y) {
    return x + y;
};
var addNum4 = function (x, y) {
    return x + y;
};
console.log(addNum(23, 14));
console.log(showMes('God is Great...!!!'));
console.log(addNum2);
console.log(addNum3(11, 22));
console.log(addNum4(14, 10));
