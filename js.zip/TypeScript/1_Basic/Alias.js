var mes;
mes = "GOD IS GREAT..!!!";
console.log(mes);
var input;
input = 1;
input = "GOD IS GREAT...!!";
