var global_var = 12;
var demoCLS = (function () {
    function demoCLS() {
        this.num = 1;
    }
    demoCLS.prototype.showNum = function () {
        var localNum = 3;
        console.log("Class Function Local Variable:" + localNum);
    };
    demoCLS.stval = 2;
    return demoCLS;
} ());
console.log("Global Number :" + global_var);
console.log(demoCLS.stval);
var obj = new demoCLS();
console.log("Class variable: " +obj.num);
console.log("Class function variable: " + obj.showNum());