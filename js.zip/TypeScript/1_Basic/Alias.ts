type chars = string;
let mes: chars;
mes = "GOD IS GREAT..!!!";
console.log(mes);

type  alphanumeric = string | number;
let input: alphanumeric;
input =1;
input = "GOD IS GREAT...!!";