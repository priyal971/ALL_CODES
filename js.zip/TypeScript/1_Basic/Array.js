var cars = ['BMW', 'Honda', 'Ford'];
console.log("cars :" + cars);
console.log("car[0]: " + cars[0]);
console.log("car[1]: " + cars[1]);
console.log("car[2]: " + cars[2]);
var Arr = [[1, 2, 3], [5, 6, 7]];
console.log(Arr[0][0]);
console.log(Arr[0][1]);
console.log(Arr[0][2]);
console.log();
console.log(Arr[1][0]);
console.log(Arr[1][1]);
console.log(Arr[1][2]);
var arrobj = new Array("Janki", "Kinjal", "Krupa");
for (var i = 0; i < arrobj.length; i++) {
    console.log(arrobj[i]);
}
var arrParse = new Array("janki", "Kinjal", "Krupa");
function showFun(arrval) {
    for (var i_1 = 0; i_1 < arrParse.length; i_1++) {
        console.log(arrParse[i_1]);
    }
}
showFun(arrParse);
