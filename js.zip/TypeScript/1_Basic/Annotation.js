function showFun(id, nm) {
    console.log("id =" + id + ", Name =" + nm);
}
showFun(1, "Janki Purohit");
var person;
person = {
    id: 1,
    nm: "Janki Purohit"
};
console.log(person.id + "" + person.nm);
function sum(n1, n2) {
    return n1 + n2;
}
var Addition = sum(10, 20);
console.log("Add :" + Addition);
