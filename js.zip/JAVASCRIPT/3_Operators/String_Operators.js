let s1 = "Janki";
let s2 = "Purohit";
let s3 = s1 + " " + s2;
document.write(s3);