
let Cars = {Company:"BMW", Model:"X4", Color:"White", Cost:10000000};
document.write(Cars.Company + " " + Cars.Model + " " + Cars.Color + " " + Cars.Cost);

const CarsObj = {Company:"BMW", Model:"X4", Color:"White", Cost:10000000};
document.write("<br/>"+CarsObj.Company + " " + CarsObj.Model + " " + CarsObj.Color + " " + CarsObj.Cost);