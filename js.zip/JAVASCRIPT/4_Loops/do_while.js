let j=0;
do{
  document.write("<br/>"+j);
  j++;
}
while (j < 10);