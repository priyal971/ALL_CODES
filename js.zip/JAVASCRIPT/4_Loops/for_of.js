const cities = ["Manali", "Ujjain", "Rajkot"];
for (C of cities) {
  document.write("<br/>"+C);
}