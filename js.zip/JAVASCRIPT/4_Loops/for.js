for (let i = 0; i < 5; i++) {
    document.write("The number is " + i + "<br>");
  }