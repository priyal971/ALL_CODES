import './App.css';
import Person from '../src/Component/UpdateClassComponent';

function App() {
  return (
  <Person/>
  //<UseStateFun/>
  );
}

export default App;

