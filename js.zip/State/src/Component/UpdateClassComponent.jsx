import React from "react";

class Person extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            name: "Janki Purohit",
            contactno: "9313793084",
            salary: "25000"
        };
    }
    updateSalary = () => {
        this.setState({salary: 30000});
    }
    render(){
        return(
            <div>
                <h1>My Name is{this.state.name}</h1>
                <p>
                    My Contact no. is{this.state.contactno}
                </p>
                <p>
                    My salary/month is{this.state.salary}
                </p>
            </div>
        );
    }
}
export default Person;