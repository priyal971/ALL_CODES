import React from "react";
import { ReactDOM } from "react";

class LifeCycle extends React.Component{
    constructor(props)
    {
        super(props);
        this.state = {Demo : "God is Great...!!!!"};
    }
    componentWillUnmount()
    {
        alert("componentwillmount() Called.");
        console.log("componentWillMoount() called");
    }
    componentDidMount()
    {
        alert("componentDidMount() Called.");
        console.log("componentDidMount() Called");
    }
    changeState(){
        this.changeState({Demo : "God is Great..."});
        console.log(this.state.Demo);
    }
    render()
    {
        return(
            <div>
                <h1>{this.state.Demo}</h1>
                <h2><a onClick={this.changeState.bind(this)}>Click Me To Change The State.</a>
                </h2>
            </div>
        );
    }
    shouldComponentUpdate(nextProps, nextState)
    {
        alert("shouldComponentUpdate() called");
        console.log("shouldCompobnentUpdate() called")
        return true;
    }
    componentWillUpdate()
    {
        alert("componentWillUpdate() Called.");
        console.log("componentWillUpdate() Called.");
    }
 
    componentDidUpdate()
    {
        alert("componentDidUpdate() Called");
        console.log("componentDidUpdate() Called.");
    }

}
ReactDOM.render(<LifeCycle />,document.getElementById('root'));
export default LifeCycle;
