import React from "react";

class SecondComponent extends React.Component{
    render(){
        const internalcssdemo = {fontSize: '80px', color:'red'}
        return <h1 style={internalcssdemo}>Second Component</h1>
    }
}
export default SecondComponent;