import React from "react";

class FourthComponent extends React.Component{
    render(){
        return<h1>Fourth Component.</h1>
    }
}
export default FourthComponent;