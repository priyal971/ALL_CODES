import { AppBar, Toolbar, makeStyles } from '@material-ui/core';
import { NavLink } from 'react-router-dom';

// Hooks are a new addition in React 16.8. 
// React hooks use state and other React features without writing a class.

// Internal Material UI Style Manipulation.
// makeStyles is a function from Material-UI that allows us to create CSS classes and rules using JavaScript objects. 
// The makeStyles function returns a React hook that we can use in a functional component to access the styles and classes. Then, we can apply these styles to any element in our component.
const useStyle = makeStyles({
    header: {
        background: '#111111',
    },
    tabs: {
        color: '#FFFFFF',
        marginRight: 20,
        textDecoration: 'none',
        fontSize: 20
    }
})

const NavBar = () => {
    // useStyles is simply the naming convention of the hook created and returned by makeStyles. 
    // useStyles definitely is a hook; try calling it outside of the function component and you will get an error.

    const classes = useStyle();
    return (
        <AppBar position="static" className={classes.header}>
            <Toolbar>
                <NavLink className={classes.tabs} to="./">React Navigation Demo</NavLink>
                <NavLink className={classes.tabs} to="./">First</NavLink>
                <NavLink className={classes.tabs} to="./SecondComponent">Second</NavLink>
                <NavLink className={classes.tabs} to="./ThirdComponent">Third</NavLink>
                <NavLink className={classes.tabs} to="./FourthComponent">Fourth</NavLink>
            </Toolbar>
        </AppBar>
    )
}

export default NavBar;