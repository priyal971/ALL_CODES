# fdp_mern
hello we are learning mern technology.. 
Janki purohit
From Gandhinagar
Assistant Professors
at silver oak university
